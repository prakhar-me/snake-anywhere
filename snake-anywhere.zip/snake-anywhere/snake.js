// snake.js — SnakeGame engine
// Canvas is fully transparent — only game elements are drawn over the live page.

class SnakeGame {
  constructor(canvas, callbacks = {}) {
    this.canvas = canvas;
    this.ctx = canvas.getContext("2d");
    this.onScoreUpdate = callbacks.onScoreUpdate || (() => {});
    this.onGameOver = callbacks.onGameOver || (() => {});

    this.CELL = 22;
    this.score = 0;
    this.running = false;
    this.frameId = null;
    this.lastTime = 0;
    this.interval = 130;

    this._keyHandler = this._handleKey.bind(this);
    this._resizeHandler = this._resize.bind(this);

    this._resize();
    window.addEventListener("resize", this._resizeHandler);
    document.addEventListener("keydown", this._keyHandler, true);
  }

  _resize() {
    this.canvas.width = window.innerWidth;
    this.canvas.height = window.innerHeight;
    this.cols = Math.floor(this.canvas.width / this.CELL);
    this.rows = Math.floor(this.canvas.height / this.CELL);
  }

  _initState() {
    const midCol = Math.floor(this.cols / 2);
    const midRow = Math.floor(this.rows / 2);
    this.snake = [
      { x: midCol,     y: midRow },
      { x: midCol - 1, y: midRow },
      { x: midCol - 2, y: midRow }
    ];
    this.dir      = { x: 1, y: 0 };
    this.nextDir  = { x: 1, y: 0 };
    this.score    = 0;
    this.onScoreUpdate(0);
    this._placeFood();
  }

  _placeFood() {
    const occupied = new Set(this.snake.map(s => `${s.x},${s.y}`));
    let pos;
    do {
      pos = {
        x: Math.floor(Math.random() * this.cols),
        y: Math.floor(Math.random() * this.rows)
      };
    } while (occupied.has(`${pos.x},${pos.y}`));
    this.food = pos;
  }

  _handleKey(e) {
    const MAP = {
      ArrowUp:    { x: 0,  y: -1 },
      ArrowDown:  { x: 0,  y:  1 },
      ArrowLeft:  { x: -1, y:  0 },
      ArrowRight: { x: 1,  y:  0 },
      w: { x: 0,  y: -1 }, W: { x: 0,  y: -1 },
      s: { x: 0,  y:  1 }, S: { x: 0,  y:  1 },
      a: { x: -1, y:  0 }, A: { x: -1, y:  0 },
      d: { x: 1,  y:  0 }, D: { x: 1,  y:  0 }
    };
    const newDir = MAP[e.key];
    if (newDir) {
      if (newDir.x !== -this.dir.x || newDir.y !== -this.dir.y) {
        this.nextDir = newDir;
      }
      if (e.key.startsWith("Arrow")) {
        e.preventDefault();
        e.stopImmediatePropagation();
      }
    }
  }

  _tick() {
    this.dir = this.nextDir;
    const head = this.snake[0];
    const next = {
      x: (head.x + this.dir.x + this.cols) % this.cols,
      y: (head.y + this.dir.y + this.rows) % this.rows
    };

    if (this.snake.some(s => s.x === next.x && s.y === next.y)) {
      this.running = false;
      this._drawDeathFrame();
      this.onGameOver(this.score);
      return;
    }

    this.snake.unshift(next);

    if (next.x === this.food.x && next.y === this.food.y) {
      this.score++;
      this.onScoreUpdate(this.score);
      this.interval = Math.max(65, this.interval - 2);
      this._placeFood();
    } else {
      this.snake.pop();
    }

    this._draw();
  }

  _draw() {
    const ctx = this.ctx;
    const C   = this.CELL;
    const W   = this.canvas.width;
    const H   = this.canvas.height;

    // Fully transparent clear — website shows through
    ctx.clearRect(0, 0, W, H);

    // ── Food ──────────────────────────────────────────────────────────────
    const fx = this.food.x * C + C / 2;
    const fy = this.food.y * C + C / 2;
    const pulse = 0.5 + 0.5 * Math.sin(Date.now() / 180);
    const fr = (C / 2 - 3) * (0.85 + 0.15 * pulse);

    // Outer glow ring (visible on any background)
    ctx.beginPath();
    ctx.arc(fx, fy, fr + 4, 0, Math.PI * 2);
    ctx.fillStyle = `rgba(255, 80, 80, ${0.15 * pulse})`;
    ctx.fill();

    // Food body — white outline so it pops on any page color
    ctx.beginPath();
    ctx.arc(fx, fy, fr, 0, Math.PI * 2);
    ctx.fillStyle = "#ff4444";
    ctx.strokeStyle = "rgba(255,255,255,0.9)";
    ctx.lineWidth = 1.5;
    ctx.fill();
    ctx.stroke();

    // ── Snake ─────────────────────────────────────────────────────────────
    const len = this.snake.length;

    this.snake.forEach((seg, i) => {
      const x   = seg.x * C;
      const y   = seg.y * C;
      const pad = 2;
      const r   = 5;
      const t   = i / len; // 0 = head, 1 = tail

      // Each segment: filled + white stroke so it's legible on any bg
      const green = Math.round(220 - t * 60);   // fades from 220→160
      const alpha = 1 - t * 0.5;               // fades from 1→0.5

      ctx.beginPath();
      ctx.roundRect(x + pad, y + pad, C - pad * 2, C - pad * 2, r);

      ctx.fillStyle = `rgba(30, ${green}, 70, ${alpha})`;
      ctx.strokeStyle = i === 0
        ? "rgba(255,255,255,0.95)"              // head — bright white border
        : `rgba(255,255,255,${0.5 - t * 0.3})`; // body fades out
      ctx.lineWidth = i === 0 ? 2 : 1.2;

      ctx.fill();
      ctx.stroke();

      // Neon inner highlight on head
      if (i === 0) {
        ctx.beginPath();
        ctx.roundRect(x + pad, y + pad, C - pad * 2, C - pad * 2, r);
        ctx.strokeStyle = "rgba(57, 255, 115, 0.7)";
        ctx.lineWidth = 1;
        ctx.stroke();
      }
    });

    // ── Eyes ──────────────────────────────────────────────────────────────
    const hx = this.snake[0].x * C;
    const hy = this.snake[0].y * C;
    const eyeR = C * 0.1;
    this._getEyeOffsets().forEach(([ox, oy]) => {
      ctx.beginPath();
      ctx.arc(hx + ox, hy + oy, eyeR, 0, Math.PI * 2);
      ctx.fillStyle = "#fff";
      ctx.fill();
      // pupil
      ctx.beginPath();
      ctx.arc(hx + ox + this.dir.x * eyeR * 0.4, hy + oy + this.dir.y * eyeR * 0.4, eyeR * 0.55, 0, Math.PI * 2);
      ctx.fillStyle = "#0a2010";
      ctx.fill();
    });
  }

  _getEyeOffsets() {
    const C = this.CELL;
    const d = this.dir;
    if (d.x === 1)  return [[C * 0.72, C * 0.28], [C * 0.72, C * 0.68]];
    if (d.x === -1) return [[C * 0.28, C * 0.28], [C * 0.28, C * 0.68]];
    if (d.y === -1) return [[C * 0.28, C * 0.28], [C * 0.68, C * 0.28]];
    return                  [[C * 0.28, C * 0.72], [C * 0.68, C * 0.72]];
  }

  _drawDeathFrame() {
    const ctx = this.ctx;
    const C   = this.CELL;
    const seg = this.snake[0];
    ctx.beginPath();
    ctx.roundRect(seg.x * C + 2, seg.y * C + 2, C - 4, C - 4, 5);
    ctx.fillStyle = "rgba(255, 50, 50, 0.75)";
    ctx.fill();
    ctx.strokeStyle = "#fff";
    ctx.lineWidth = 2;
    ctx.stroke();
  }

  _loop(timestamp) {
    if (!this.running) return;
    if (timestamp - this.lastTime >= this.interval) {
      this.lastTime = timestamp;
      this._tick();
    }
    this.frameId = requestAnimationFrame(this._loop.bind(this));
  }

  start() {
    this._resize();
    this._initState();
    this.running  = true;
    this.lastTime = 0;
    this.frameId  = requestAnimationFrame(this._loop.bind(this));
  }

  restart() {
    this.running = false;
    cancelAnimationFrame(this.frameId);
    this.interval = 130;
    this.start();
  }

  destroy() {
    this.running = false;
    cancelAnimationFrame(this.frameId);
    document.removeEventListener("keydown", this._keyHandler, true);
    window.removeEventListener("resize", this._resizeHandler);
  }
}
