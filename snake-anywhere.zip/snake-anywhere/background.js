// background.js
// Handles icon click → injects snake.js then content.js into the active tab.

chrome.action.onClicked.addListener(async (tab) => {
  if (!tab.id) return;

  const restricted = !tab.url ||
    tab.url.startsWith("chrome://") ||
    tab.url.startsWith("chrome-extension://") ||
    tab.url.startsWith("edge://") ||
    tab.url.startsWith("about:") ||
    tab.url.startsWith("data:");

  if (restricted) {
    console.log("Snake Anywhere: Cannot inject on restricted page.");
    return;
  }

  try {
    // Inject game engine first, then the content manager
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files: ["snake.js"]
    });

    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files: ["content.js"]
    });

    await chrome.scripting.insertCSS({
      target: { tabId: tab.id },
      files: ["snake.css"]
    });

    await chrome.tabs.sendMessage(tab.id, { action: "toggle" });

  } catch (err) {
    // Scripts likely already injected — just toggle
    try {
      await chrome.tabs.sendMessage(tab.id, { action: "toggle" });
    } catch (e) {
      console.error("Snake Anywhere: Could not reach tab.", e);
    }
  }
});
