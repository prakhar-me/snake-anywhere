// content.js
(function () {
  if (window.__snakeAnywhereLoaded) return;
  window.__snakeAnywhereLoaded = true;

  let overlayEl = null;
  let snakeGame = null;
  let isDead = false;

  function mountOverlay() {
    if (overlayEl) return;

    overlayEl = document.createElement("div");
    overlayEl.id = "snake-anywhere-overlay";

    const canvas = document.createElement("canvas");
    canvas.id = "snake-anywhere-canvas";

    // Score — just the number, top left
    const scoreEl = document.createElement("div");
    scoreEl.id = "sa-score";
    scoreEl.textContent = "0";

    // Dead state — inline, replaces score briefly
    const deadEl = document.createElement("div");
    deadEl.id = "sa-dead";
    deadEl.innerHTML = `<span id="sa-dead-score"></span><span class="sa-dead-hint">R restart · ESC close</span>`;
    deadEl.style.display = "none";

    overlayEl.appendChild(canvas);
    overlayEl.appendChild(scoreEl);
    overlayEl.appendChild(deadEl);
    document.documentElement.appendChild(overlayEl);

    snakeGame = new SnakeGame(canvas, {
      onScoreUpdate: (score) => {
        scoreEl.textContent = score;
      },
      onGameOver: (score) => {
        isDead = true;
        scoreEl.style.display = "none";
        document.getElementById("sa-dead-score").textContent = score;
        deadEl.style.display = "flex";
      }
    });

    snakeGame.start();
    document.addEventListener("keydown", handleGlobalKey, true);
  }

  function unmountOverlay() {
    if (!overlayEl) return;
    document.removeEventListener("keydown", handleGlobalKey, true);
    snakeGame && snakeGame.destroy();
    snakeGame = null;
    overlayEl.remove();
    overlayEl = null;
    isDead = false;
  }

  function restartGame() {
    const scoreEl = document.getElementById("sa-score");
    const deadEl  = document.getElementById("sa-dead");
    if (!scoreEl || !deadEl) return;
    isDead = false;
    deadEl.style.display = "none";
    scoreEl.style.display = "block";
    scoreEl.textContent = "0";
    snakeGame.restart();
  }

  function handleGlobalKey(e) {
    if (e.key === "Escape") {
      e.stopImmediatePropagation();
      unmountOverlay();
    }
    if ((e.key === "r" || e.key === "R") && isDead) {
      e.stopImmediatePropagation();
      restartGame();
    }
  }

  chrome.runtime.onMessage.addListener((message) => {
    if (message.action === "toggle") {
      overlayEl ? unmountOverlay() : mountOverlay();
    }
  });
})();
